/* FitLog Pro – Einstellungen & Datensicherung */
window.FIT = window.FIT || {};
FIT.views = FIT.views || {};

FIT.views.settings = (() => {
  const U = FIT.util;
  const S = FIT.store;
  const UI = FIT.ui;

  function render(el) {
    const p = S.state.profile;
    const bytes = new Blob([JSON.stringify(S.state)]).size;
    const kb = Math.max(1, Math.round(bytes / 1024));

    el.innerHTML =
      '<section class="page-head">' +
        '<div><h1>Einstellungen</h1><p>Profil, Tagesziele und deine lokalen Daten.</p></div>' +
      '</section>' +

      '<div class="settings-grid">' +
        '<section class="card">' +
          '<div class="card-head"><div><h2>Profil & Ziele</h2><p class="muted">Körperdaten eingeben und Ziele automatisch berechnen lassen.</p></div></div>' +
          '<form id="profileForm" class="form-stack">' +
            '<div class="form-grid two">' +
              UI.field('Name (optional)', UI.input('name', 'text', p.name, 'maxlength="40" placeholder="Dein Name"')) +
              UI.field('Trainings pro Woche (Ziel)', UI.input('weeklyGoal', 'number', p.weeklyGoal, 'min="0" max="21" step="1"')) +
            '</div>' +
            '<div class="section-label">Körperdaten</div>' +
            '<div class="form-grid four">' +
              UI.field('Größe (cm)', UI.input('height', 'number', p.height || '', 'min="100" max="230" step="1" placeholder="175"')) +
              UI.field('Gewicht (kg)', UI.input('weight', 'number', p.weight || '', 'min="30" max="250" step="0.1" placeholder="75"')) +
              UI.field('Alter', UI.input('age', 'number', p.age || '', 'min="14" max="90" step="1" placeholder="30"')) +
              UI.field('Geschlecht', '<select class="input" name="gender">' +
                '<option value="male"' + (p.gender !== 'female' ? ' selected' : '') + '>Männlich</option>' +
                '<option value="female"' + (p.gender === 'female' ? ' selected' : '') + '>Weiblich</option>' +
              '</select>') +
            '</div>' +
            '<div class="form-grid two">' +
              UI.field('Aktivität', '<select class="input" name="activity">' +
                '<option value="sedentary"' + (p.activity === 'sedentary' ? ' selected' : '') + '>Wenig (Büro, kaum Sport)</option>' +
                '<option value="light"' + (p.activity === 'light' ? ' selected' : '') + '>Leicht (1–2× Training/Woche)</option>' +
                '<option value="moderate"' + (p.activity !== 'sedentary' && p.activity !== 'light' && p.activity !== 'active' && p.activity !== 'very' ? ' selected' : '') + '>Moderat (3–4× Training/Woche)</option>' +
                '<option value="active"' + (p.activity === 'active' ? ' selected' : '') + '>Aktiv (5–6× Training/Woche)</option>' +
                '<option value="very"' + (p.activity === 'very' ? ' selected' : '') + '>Sehr aktiv (täglich / körperliche Arbeit)</option>' +
              '</select>') +
              UI.field('Ziel', '<select class="input" name="goalMode">' +
                '<option value="maintain"' + ((p.goalMode || 'maintain') === 'maintain' ? ' selected' : '') + '>Gewicht halten</option>' +
                '<option value="lose"' + (p.goalMode === 'lose' ? ' selected' : '') + '>Abnehmen (−500 kcal)</option>' +
                '<option value="gain"' + (p.goalMode === 'gain' ? ' selected' : '') + '>Zunehmen (+300 kcal)</option>' +
              '</select>') +
            '</div>' +
            '<div class="row gap">' +
              '<button type="button" class="btn ghost" id="calcGoals">' + UI.icon('target') + ' Ziele aus Körperdaten berechnen</button>' +
              '<span class="muted small-text" id="calcInfo"></span>' +
            '</div>' +
            '<div class="section-label">Tägliche Makro-Ziele</div>' +
            '<div class="form-grid four">' +
              UI.field('Kalorien (kcal)', UI.input('kcal', 'number', p.goals.kcal, 'min="0" step="any"')) +
              UI.field('Protein (g)', UI.input('protein', 'number', p.goals.protein, 'min="0" step="any"')) +
              UI.field('Kohlenhydrate (g)', UI.input('carbs', 'number', p.goals.carbs, 'min="0" step="any"')) +
              UI.field('Fett (g)', UI.input('fat', 'number', p.goals.fat, 'min="0" step="any"')) +
            '</div>' +
            '<div><button class="btn primary" type="submit">' + UI.icon('check') + ' Profil & Ziele speichern</button></div>' +
          '</form>' +
        '</section>' +

        '<section class="card">' +
          '<div class="card-head"><div><h2>Daten & Sicherung</h2><p class="muted">Alles liegt nur auf diesem Gerät (' + kb + ' KB belegt).</p></div></div>' +
          '<p class="muted small-text">Sichere deine Daten regelmäßig als JSON-Datei – zum Beispiel vor einem Browser-Wechsel oder zum Übertragen auf ein anderes Gerät.</p>' +
          '<div class="settings-actions">' +
            '<button class="btn ghost" id="exportData">' + UI.icon('download') + ' Backup exportieren</button>' +
            '<button class="btn ghost" id="importData">' + UI.icon('upload') + ' Backup importieren</button>' +
            '<input type="file" id="importFile" accept=".json,application/json" hidden>' +
          '</div>' +
          '<div class="divider"></div>' +
          '<h3 class="danger-title">Alles zurücksetzen</h3>' +
          '<p class="muted small-text">Löscht Zähler, Rezepte, Tagebuch, Pläne und Trainings dauerhaft.</p>' +
          '<button class="btn danger-outline" id="resetData">' + UI.icon('trash') + ' Alle Daten löschen</button>' +
        '</section>' +

        '<section class="card wide-card">' +
          '<div class="card-head"><div><h2>Über FitLog Pro</h2><p class="muted">Version 1.0 · offline & ohne Konto</p></div></div>' +
          '<div class="about-grid">' +
            '<div><strong>' + UI.icon('shield') + ' Datenschutz</strong><p>Keine Cloud, kein Tracking, keine externen Ressourcen. Alle Eingaben bleiben im lokalen Speicher deines Browsers.</p></div>' +
            '<div><strong>' + UI.icon('download') + ' Offline</strong><p>Die App funktioniert nach dem ersten Aufruf auch ohne Internet. Über das Browser-Menü lässt sie sich als App installieren.</p></div>' +
            '<div><strong>' + UI.icon('recipes') + ' Rezepte & Makros</strong><p>Speichere Gerichte pro Portion und übernimm sie mit einem Klick in dein Tages-Tagebuch.</p></div>' +
            '<div><strong>' + UI.icon('dumbbell') + ' Training</strong><p>Pläne mit Tagen und Übungen anlegen, Einheiten starten und Volumen automatisch berechnen.</p></div>' +
          '</div>' +
        '</section>' +
      '</div>';

    const calcGoals = () => {
      const f = el.querySelector('#profileForm');
      const height = Number(String(f.querySelector('[name=height]').value || '').replace(',', '.'));
      const weight = Number(String(f.querySelector('[name=weight]').value || '').replace(',', '.'));
      const age = Number(String(f.querySelector('[name=age]').value || '').replace(',', '.'));
      const gender = f.querySelector('[name=gender]').value;
      const activity = f.querySelector('[name=activity]').value;
      const goalMode = f.querySelector('[name=goalMode]').value;
      if (!Number.isFinite(height) || !Number.isFinite(weight) || !Number.isFinite(age) || height <= 0 || weight <= 0 || age <= 0) {
        UI.toast('Bitte Größe, Gewicht und Alter eingeben.', 'error');
        return;
      }
      const bmr = gender === 'female'
        ? 10 * weight + 6.25 * height - 5 * age - 161
        : 10 * weight + 6.25 * height - 5 * age + 5;
      const factors = { sedentary: 1.2, light: 1.375, moderate: 1.55, active: 1.725, very: 1.9 };
      const tdee = bmr * (factors[activity] || 1.55);
      let calories = tdee;
      if (goalMode === 'lose') calories -= 500;
      if (goalMode === 'gain') calories += 300;
      calories = Math.max(1200, Math.round(calories));
      const proteinPerKg = goalMode === 'lose' ? 2.0 : 1.8;
      const protein = Math.round(weight * proteinPerKg);
      const fat = Math.round((calories * 0.25) / 9);
      const carbs = Math.max(0, Math.round((calories - protein * 4 - fat * 9) / 4));
      f.querySelector('[name=kcal]').value = calories;
      f.querySelector('[name=protein]').value = protein;
      f.querySelector('[name=carbs]').value = carbs;
      f.querySelector('[name=fat]').value = fat;
      const info = el.querySelector('#calcInfo');
      if (info) info.textContent = 'Grundumsatz ' + Math.round(bmr) + ' kcal · Gesamtumsatz ' + Math.round(tdee) + ' kcal · Ziel ' + calories + ' kcal';
      UI.toast('Ziele berechnet');
    };

    el.querySelector('#calcGoals')?.addEventListener('click', calcGoals);

    el.querySelector('#profileForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const f = e.target;
      const num = (sel, def) => {
        const v = Number(String(f.querySelector(sel).value || '').replace(',', '.'));
        return Number.isFinite(v) && v >= 0 ? v : def;
      };
      S.state.profile.name = String(f.querySelector('[name=name]').value || '').trim();
      S.state.profile.weeklyGoal = Math.round(num('[name=weeklyGoal]', 4));
      S.state.profile.height = num('[name=height]', 0) || null;
      S.state.profile.weight = num('[name=weight]', 0) || null;
      S.state.profile.age = num('[name=age]', 0) || null;
      S.state.profile.gender = f.querySelector('[name=gender]').value;
      S.state.profile.activity = f.querySelector('[name=activity]').value;
      S.state.profile.goalMode = f.querySelector('[name=goalMode]').value;
      S.state.profile.goals = {
        kcal: Math.round(num('[name=kcal]', 2400)),
        protein: Math.round(num('[name=protein]', 180)),
        carbs: Math.round(num('[name=carbs]', 250)),
        fat: Math.round(num('[name=fat]', 70))
      };
      S.save();
      UI.toast('Profil & Ziele gespeichert');
      FIT.app.renderNav();
    });

    el.querySelector('#exportData').addEventListener('click', () => {
      U.download('fitness-studio_' + U.timestamp() + '.json', S.exportJSON());
      UI.toast('Backup exportiert');
    });

    const fileInput = el.querySelector('#importFile');
    el.querySelector('#importData').addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files && fileInput.files[0];
      fileInput.value = '';
      if (!file) return;
      try {
        const text = await U.readTextFile(file);
        const ok = await UI.confirm({
          title: 'Backup importieren',
          message: 'Die aktuelle Datenlage wird vollständig durch das Backup ersetzt. Fortfahren?',
          confirmLabel: 'Importieren',
          danger: false
        });
        if (!ok) return;
        S.importJSON(text);
        UI.toast('Backup importiert');
        FIT.app.rerender();
      } catch (err) {
        UI.toast(err.message || 'Import fehlgeschlagen', 'error');
      }
    });

    el.querySelector('#resetData').addEventListener('click', async () => {
      const ok = await UI.confirm({
        title: 'Wirklich alles löschen?',
        message: 'Sämtliche Zähler, Rezepte, Tagebuch-Einträge, Pläne und Trainings werden unwiderruflich entfernt.',
        confirmLabel: 'Alles löschen'
      });
      if (!ok) return;
      S.reset();
      UI.toast('Alle Daten gelöscht');
      location.hash = '#/dashboard';
      FIT.app.rerender();
    });
  }

  return { render };
})();
